// Admin configuration
const ADMIN_USERNAME = '@Gbbbjjbbi';

module.exports = {
  ADMIN_USERNAME
};