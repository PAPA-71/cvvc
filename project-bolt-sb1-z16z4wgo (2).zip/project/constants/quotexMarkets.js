// List of markets available for Quotex
const QUOTEX_MARKETS = [
  'USD/BRL-OTC',
  'USD/BDT-OTC',
  'USD/PKR-OTC', 
  'USD/DZD-OTC',
  'USD/MXN-OTC',
  'USD/NGN-OTC',
  'USD/JPY-OTC'
];

// Create paginated buttons for Quotex markets
const createQuotexPaginatedButtons = (markets, currentPage, itemsPerPage = 4) => {
  const start = currentPage * itemsPerPage;
  const paginatedMarkets = markets.slice(start, start + itemsPerPage);
  const totalPages = Math.ceil(markets.length / itemsPerPage);

  // Create market buttons
  const marketButtons = paginatedMarkets.map(market => [{
    text: market,
    callback_data: `quotex_market_${market}`
  }]);

  // Add navigation buttons
  const navigationButtons = [];
  
  if (currentPage > 0) {
    navigationButtons.push({ text: '⬅️ Back', callback_data: `quotex_page_${currentPage - 1}` });
  }
  
  if (currentPage < totalPages - 1) {
    navigationButtons.push({ text: 'Next ➡️', callback_data: `quotex_page_${currentPage + 1}` });
  }

  return [...marketButtons, navigationButtons];
};

module.exports = {
  QUOTEX_MARKETS,
  createQuotexPaginatedButtons
};