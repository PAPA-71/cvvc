// Available trading time options in minutes
const TRADING_TIMES = [1, 2, 5];

// Create trading time buttons
const createTimeButtons = () => {
  return TRADING_TIMES.map(time => [{
    text: `${time} minute${time > 1 ? 's' : ''}`,
    callback_data: `time_${time}`
  }]);
};

module.exports = {
  TRADING_TIMES,
  createTimeButtons
};