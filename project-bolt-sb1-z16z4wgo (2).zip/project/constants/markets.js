// List of all available markets
const MARKETS = [
  'EUR/USD OTC', 'AUD/CAD OTC', 'AUD/CHF OTC', 'AUD/JPY OTC', 'AUD/NZD OTC',
  'AUD/USD OTC', 'CAD/CHF OTC', 'CAD/JPY OTC', 'CHF/JPY OTC', 'EUR/CHF OTC',
  'EUR/GBP OTC', 'EUR/JPY OTC', 'EUR/NZD OTC', 'GBP/AUD OTC', 'GBP/JPY OTC',
  'GBP/USD OTC', 'NZD/JPY OTC', 'NZD/USD OTC', 'USD/CAD OTC', 'USD/CHF OTC',
  'USD/JPY OTC', 'USD/RUB OTC', 'EUR/RUB OTC', 'CHF/NOK OTC', 'EUR/HUF OTC',
  'USD/CNH OTC', 'EUR/TRY OTC', 'USD/INR OTC', 'USD/SGD OTC', 'USD/CLP OTC',
  'USD/MYR OTC', 'USD/THB OTC', 'USD/VND OTC', 'USD/PKR OTC', 'USD/COP OTC',
  'USD/EGP OTC', 'USD/PHP OTC', 'USD/MXN OTC', 'USD/DZD OTC', 'USD/ARS OTC',
  'USD/IDR OTC', 'USD/BRL OTC', 'USD/BDT OTC', 'YER/USD OTC', 'LBP/USD OTC',
  'TND/USD OTC', 'MAD/USD OTC', 'BHD/CNY OTC', 'AED/CNY OTC', 'SAR/CNY OTC',
  'QAR/CNY OTC', 'OMR/CNY OTC', 'JOD/CNY OTC'
];

// Function to create market buttons (5 markets per row)
const createMarketButtons = (markets) => {
  return markets.reduce((rows, market, index) => {
    if (index % 5 === 0) rows.push([]);
    rows[rows.length - 1].push({
      text: market,
      callback_data: `market_${market}`
    });
    return rows;
  }, []);
};

module.exports = {
  MARKETS,
  createMarketButtons
};