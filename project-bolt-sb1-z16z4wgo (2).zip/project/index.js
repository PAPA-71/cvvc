const TelegramBot = require('node-telegram-bot-api');
const { MARKETS } = require('./constants/markets');
const { QUOTEX_MARKETS, createQuotexPaginatedButtons } = require('./constants/quotexMarkets');
const { createTimeButtons } = require('./constants/tradingTimes');
const { getRandomMarket, deleteMessage } = require('./utils/messageHelpers');
const { createPaginatedButtons } = require('./utils/pagination');
const { getSignalStrength, getSignalDirection, formatSignalMessage } = require('./utils/signalHelpers');
const { hasAccess, addUser, removeUser } = require('./utils/accessControl');
const { ADMIN_USERNAME } = require('./constants/admin');

const token = '7718056493:AAEviEZfClNCSvorasotSm8OtIU11SqvjIw';
const bot = new TelegramBot(token, { polling: true });
const messageStore = new Map();
const userState = new Map();

// Access denied message
const ACCESS_DENIED_MESSAGE = `YOU ARE NOT GRANTED ACCESS ⚠️

CONTACT FOR ACCESS:
➥@oawhidshakib`;

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const firstName = msg.from.first_name;

  if (!hasAccess(chatId)) {
    const message = await bot.sendMessage(chatId, ACCESS_DENIED_MESSAGE);
    messageStore.set(chatId, message.message_id);
    return;
  }

  const welcomeMessage = await bot.sendMessage(
    chatId,
    `Hi ${firstName}! 👋🏻\n\nWelcome to our smart trading assistant at Binary ! 🦾\n\nHere you will find winning signals based on in-depth market analysis using advanced neural network technologies. 📲`,
    {
      reply_markup: {
        inline_keyboard: [[{ text: 'GET SIGNAL', callback_data: 'get_signal' }]]
      }
    }
  );

  messageStore.set(chatId, welcomeMessage.message_id);
});

// Admin commands for user management
bot.onText(/\/adminuseradd (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = msg.from.username;

  if (username !== ADMIN_USERNAME.replace('@', '')) {
    await bot.sendMessage(chatId, 'You are not authorized to use this command.');
    return;
  }

  const userToAdd = match[1];
  if (addUser(userToAdd)) {
    await bot.sendMessage(chatId, 'add member done');
  } else {
    await bot.sendMessage(chatId, 'User already has access.');
  }
});

bot.onText(/\/adminuseraremove (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = msg.from.username;

  if (username !== ADMIN_USERNAME.replace('@', '')) {
    await bot.sendMessage(chatId, 'You are not authorized to use this command.');
    return;
  }

  const userToRemove = match[1];
  if (removeUser(userToRemove)) {
    await bot.sendMessage(chatId, 'member remove done');
  } else {
    await bot.sendMessage(chatId, 'User not found in access list.');
  }
});

bot.on('callback_query', async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;

  if (!hasAccess(chatId)) {
    await bot.sendMessage(chatId, ACCESS_DENIED_MESSAGE);
    return;
  }

  const previousMessageId = messageStore.get(chatId);
  await deleteMessage(bot, chatId, previousMessageId);

  if (data === 'get_signal') {
    const message = await bot.sendMessage(
      chatId,
      'Select the broker you are interested in',
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: 'POCKET OPTION', callback_data: 'pocket_option' }],
            [{ text: 'QUOTEX', callback_data: 'quotex' }]
          ]
        }
      }
    );
    messageStore.set(chatId, message.message_id);
  } 
  else if (data === 'pocket_option' || data.startsWith('page_')) {
    const currentPage = data.startsWith('page_') ? parseInt(data.split('_')[1]) : 0;
    const recommendedMarket = getRandomMarket(MARKETS);
    
    const message = await bot.sendMessage(
      chatId,
      `Select the asset you are interested in\nBot recommendation at the moment: ${recommendedMarket}`,
      {
        reply_markup: {
          inline_keyboard: createPaginatedButtons(MARKETS, currentPage)
        }
      }
    );
    messageStore.set(chatId, message.message_id);
  }
  else if (data === 'quotex' || data.startsWith('quotex_page_')) {
    const currentPage = data.startsWith('quotex_page_') ? parseInt(data.split('_')[2]) : 0;
    const recommendedMarket = getRandomMarket(QUOTEX_MARKETS);
    
    const message = await bot.sendMessage(
      chatId,
      `Select the asset you are interested in\nBot recommendation at the moment: ${recommendedMarket}`,
      {
        reply_markup: {
          inline_keyboard: createQuotexPaginatedButtons(QUOTEX_MARKETS, currentPage)
        }
      }
    );
    messageStore.set(chatId, message.message_id);
  }
  else if (data.startsWith('market_') || data.startsWith('quotex_market_')) {
    const market = data.replace('market_', '').replace('quotex_market_', '');
    userState.set(chatId, { market });
    
    const message = await bot.sendMessage(
      chatId,
      'Select the trading time:',
      {
        reply_markup: {
          inline_keyboard: createTimeButtons()
        }
      }
    );
    messageStore.set(chatId, message.message_id);
  }
  else if (data.startsWith('time_')) {
    const time = parseInt(data.split('_')[1]);
    const state = userState.get(chatId);
    const market = state?.market;

    if (market) {
      // Send analyzing message
      const analyzingMessage = await bot.sendMessage(
        chatId,
        `🟢 ${market} Analyzing the market...`
      );
      messageStore.set(chatId, analyzingMessage.message_id);

      // Delete analyzing message after 10 seconds and send signal
      setTimeout(async () => {
        await deleteMessage(bot, chatId, analyzingMessage.message_id);
        
        const strength = getSignalStrength();
        const { direction, emoji } = getSignalDirection(Date.now());
        const signalMessage = formatSignalMessage(market, time, direction, emoji, strength);
        
        const message = await bot.sendMessage(
          chatId,
          signalMessage,
          {
            reply_markup: {
              inline_keyboard: [[
                { text: 'MORE SIGNALS', callback_data: 'get_signal' }
              ]]
            }
          }
        );
        messageStore.set(chatId, message.message_id);
      }, 10000);
    }
  }

  bot.answerCallbackQuery(callbackQuery.id);
});

console.log('Bot is running...');