// Pagination helper functions
const getPaginatedMarkets = (markets, page, itemsPerPage = 4) => {
  const start = page * itemsPerPage;
  return markets.slice(start, start + itemsPerPage);
};

const createPaginatedButtons = (markets, currentPage, itemsPerPage = 4) => {
  const paginatedMarkets = getPaginatedMarkets(markets, currentPage);
  const totalPages = Math.ceil(markets.length / itemsPerPage);
  
  // Create market buttons
  const marketButtons = paginatedMarkets.map(market => [{
    text: market,
    callback_data: `market_${market}`
  }]);

  // Add navigation buttons
  const navigationButtons = [];
  
  if (currentPage > 0) {
    navigationButtons.push({ text: '⬅️ Back', callback_data: `page_${currentPage - 1}` });
  }
  
  if (currentPage < totalPages - 1) {
    navigationButtons.push({ text: 'Next ➡️', callback_data: `page_${currentPage + 1}` });
  }

  return [...marketButtons, navigationButtons];
};

module.exports = {
  getPaginatedMarkets,
  createPaginatedButtons
};