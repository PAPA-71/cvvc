// Helper functions for message handling
const getRandomMarket = (markets) => {
  return markets[Math.floor(Math.random() * markets.length)];
};

const deleteMessage = async (bot, chatId, messageId) => {
  try {
    if (messageId) {
      await bot.deleteMessage(chatId, messageId);
    }
  } catch (error) {
    console.error('Error deleting message:', error);
  }
};

module.exports = {
  getRandomMarket,
  deleteMessage
};