// Signal generation helpers
const getSignalStrength = () => {
  return Math.floor(Math.random() * (99 - 90 + 1)) + 90; // Random number between 90-99
};

const getSignalDirection = (timestamp) => {
  const isOdd = Math.floor(timestamp / 1000) % 2 !== 0;
  return {
    direction: isOdd ? 'UP' : 'DOWN',
    emoji: isOdd ? '🟢' : '🔴'
  };
};

const formatSignalMessage = (market, time, direction, emoji, strength) => {
  return `🐲 ${market}\n🕑 Next Candle\n${emoji} ${direction}\n⌛ ${time} minute${time > 1 ? 's' : ''}\n📶 Signal strength: ${strength}%`;
};

module.exports = {
  getSignalStrength,
  getSignalDirection,
  formatSignalMessage
};