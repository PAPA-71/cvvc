// Access control management
const path = require('path');
const fs = require('fs');

const ACCESS_FILE = path.join(__dirname, '../data/access.json');

// Initialize access file if it doesn't exist
if (!fs.existsSync(path.dirname(ACCESS_FILE))) {
  fs.mkdirSync(path.dirname(ACCESS_FILE), { recursive: true });
}
if (!fs.existsSync(ACCESS_FILE)) {
  fs.writeFileSync(ACCESS_FILE, JSON.stringify({ users: [] }));
}

const getAccessList = () => {
  try {
    const data = fs.readFileSync(ACCESS_FILE);
    return JSON.parse(data);
  } catch (error) {
    return { users: [] };
  }
};

const saveAccessList = (accessList) => {
  fs.writeFileSync(ACCESS_FILE, JSON.stringify(accessList, null, 2));
};

const hasAccess = (chatId) => {
  const accessList = getAccessList();
  return accessList.users.includes(chatId.toString());
};

const addUser = (chatId) => {
  const accessList = getAccessList();
  if (!accessList.users.includes(chatId.toString())) {
    accessList.users.push(chatId.toString());
    saveAccessList(accessList);
    return true;
  }
  return false;
};

const removeUser = (chatId) => {
  const accessList = getAccessList();
  const index = accessList.users.indexOf(chatId.toString());
  if (index !== -1) {
    accessList.users.splice(index, 1);
    saveAccessList(accessList);
    return true;
  }
  return false;
};

module.exports = {
  hasAccess,
  addUser,
  removeUser
};